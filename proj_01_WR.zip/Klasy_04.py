from abc import ABC, abstractmethod

class Ptak(ABC):
    """
    Klasa opisujaca ptaka
    """

    def __init__(self, gatunek, szybkosc):
        self.gatunek = gatunek
        self.szybkosc = szybkosc

    def lataj(self):
        print("Tu", self.gatunek, "Lecę z szybkością", self.szybkosc)

    @abstractmethod
    def dodaj_odglos(self):
        pass

class Orzel(Ptak):
    """
    to jest orzel
    """
    def poluj(self):
        print("Tu", self.gatunek, "Zaczynam polowanie")


        print("odglos_1")

class Kura(Ptak):
    def __init__(self, gatunek):
        super().__init__(gatunek, 0)
        self.gatunek = gatunek

    def lataj(self):
        print("Tu", self.gatunek, "Nie lata")

    def dodaj_odglos(self):
        print("odglos_2")

#
# orzel = Ptak("Orzel", 10)
# orzel.lataj()
# kura = Ptak("Kura", 0)
# kura.lataj()
orzel_2 = Orzel("orzel", 10)
orzel_2.lataj()
kura_2 = Kura("Kura")
kura_2.lataj()
orzel_2.poluj()
orzel_2.dodaj_odglos()
kura_2.dodaj_odglos()



