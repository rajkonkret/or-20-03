# / oddziela argumenty pozycyjne od takich po nazwie

def allparams(a, b, /, c=43, *tupla, d=356, **slownik):
    print(a, b, c, tupla, d, slownik)


allparams(1, 2, 3, 4, 5, 6, 9, d=0, k=4, p=5, o=6)
