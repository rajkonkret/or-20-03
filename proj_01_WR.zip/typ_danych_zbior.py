# set - nie przechowuje  zdublowanych elementów
lista = [44, 55, 66, 77, 33, 22, 11, 33, 11]
zbior = set(lista)
print(zbior)
lista_01 = list(zbior)
print(lista_01)
lista_01.sort()
print(lista_01)
zbior_2 = {"Kraków", "kraków", "Kraków"}
print(zbior_2)
print(type(zbior_2))
print(sorted(zbior_2)) # zwraca posortowana ale juz listę
print(zbior | zbior_2)  # suma zbiorow
print(zbior & zbior_2)  # czesc wspolna
print(zbior - zbior_2)
print(zbior.difference(zbior_2))
print(zbior_2.difference(zbior))
