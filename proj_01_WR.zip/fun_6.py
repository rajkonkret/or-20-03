def liczby(c, *cyfry): # tupla
    print(c)
    print(cyfry)
    print(type(cyfry))
    suma = 0
    for i in cyfry:
        suma += i
    print(f"Suma {suma}")
    print("Suma", suma)
    ilosc = len(cyfry)
    srednia = suma / ilosc
    print("średnia:", srednia )


# liczby(1)
# liczby(1, 2)
liczby(1, 2, 3, 4)