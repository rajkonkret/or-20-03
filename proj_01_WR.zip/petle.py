import random

lista_parzysta = []
lista_nieparzysta = []
for i in range(10):  # 0...9
    if i % 2 == 0:  # reszta z dzielenie
        print(i)
        lista_parzysta.append(i)
    else:
        lista_nieparzysta.append(i)

print(lista_parzysta)
print(lista_nieparzysta)

lista_wyn = []
lista_lotto = list(range(1, 50))
for i in range(6):
    wyn = random.choice(lista_lotto)
    print(wyn)
    lista_lotto.remove(wyn)
    lista_wyn.append(wyn)

print(sorted(lista_wyn))
print(lista_lotto)
print(type(lista_lotto))
