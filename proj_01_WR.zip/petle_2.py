lista_01 = [1, 3, 55, 77, 88, 43]

for cyfra in lista_01:
    if cyfra == 2: # sprawdzenie czy = 2
        cyfra += 1 # cyfra = cyfra + 1
    print(cyfra)

imiona = ["Radek", "Zenek", "Marta", "Jan"]
for p in imiona:
    print(p)

for p in range(len(imiona)):    # range(3) - liczy 0..2
    print(p, imiona[p])

wiek = [22, 33, 44, 12]

for p, w in enumerate(imiona):
    print(p, w)
for p, w in enumerate(imiona):
    print(p, w, wiek[p])

for l, w in  zip(imiona, wiek):
    print (l, w)

ind = list(range(len(imiona)))
for i, l, w in  zip(ind, imiona, wiek):
    print (i, l, w)