# klasa - szablon wg którego zbudujemy obiekt klasy

class Human:
    """
    To jest przykład tresci opisowej w kodzie
    obiekty z małe litery
    klasy z dużej liery

    """
    imie = ""
    wiek = 2
    plec = "k"

    def powitanie(self):
        """
        metoda witająca
        :return:
        """
        print("Nazywam się", self.imie)

    def ruszaj(self):
        if self.plec == "k":
            print("ruszyłam")

        elif self.plec == "m":
            print("ruszyłem")

        else:
            print("Żle podana płeć")

# wyswietelnie dokumentacji klasy
print(Human.__doc__)

# budowanie obiektu klasy Human
cz_1 = Human()
print(cz_1)
print(cz_1.imie)
print(cz_1.wiek)
print(cz_1.plec)
cz_1.imie = "Jan"
cz_1.wiek = "54"
cz_1.plec = "m"
print(cz_1.imie)
print(cz_1.wiek)
print(cz_1.plec)

cz_1.powitanie() # wywołanie bez self
cz_1.ruszaj()


