
data = input("podaj rok bitwy pod Grunwaldem") # input zawsze zwraca string
print(type(data))

match data:
    case "1410":
        print("Ocena 5")
    case _:
        print("Musisz chłopie się pouczyć")

