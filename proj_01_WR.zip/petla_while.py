licznik = 0
while True:
    licznik += 1
    print("liczba", licznik)
    if licznik == 10000:
        break  # przerwanie działania


while licznik < 100
