class Human:
    """
    Klasa opisująca człowieka w Pythonie
    """
# własny konstruktor klasy
    def __init__(self, imie, wiek=39, plec="m"):
        self.imie = imie
        self.wiek = wiek
        self.plec = plec

    def powitanie(self):
        """
        metoda witająca
        :return:
        """
        print("Nazywam się", self.imie)

    def ruszaj(self):
        if self.plec == "k":
            print("ruszyłam")

        elif self.plec == "m":
            print("ruszyłem")

        else:
            print("Żle podana płeć")


cz_1 = Human("Andrzej", 49, "m")

print(cz_1.imie)
print(cz_1.wiek)
print(cz_1.plec)
cz_1.powitanie()
cz_1.ruszaj()