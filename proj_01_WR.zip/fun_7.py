def connect(**opcje): # slownik
    print(opcje)
    print(type(opcje))
    connect_param = {
        'host': '127.0.0.1',
        'port': '8888'
            }
    connect_param['pwd'] = opcje
    print(connect_param)

connect(name="Andrzej")
connect(name='Andrzej', nazwisko="Nowak")
connect()
