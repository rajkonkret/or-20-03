class Dom:
    """
    Klasa opisująca dom w Pythonie
    """

    def __init__(self, metraz):
        self.__metraz = metraz  # pole prywatne

    def zmien_metraz(self):
        wybor = input("Podaj metraz")
        self.__metraz = int(wybor)
        print("Teraz masz metraz:", self.__metraz)
        self.__farba()

    def __farba(self):  # funkcja prywatna
        print("Zabrakło farby")


dom_1 = Dom(190)
# print(dom_1.metraz)
dom_1.zmien_metraz()
