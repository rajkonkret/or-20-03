with open('test.log', 'w', encoding='utf-8') as f:  # f - filehandler, dowolna nazwa
    f.write("Jan\n")
    f.write("Łukasz\n")
    f.write("Ola\n")

with open('test.log', 'a', encoding='utf-8') as f:
    f.write("Andrzej\n")
    f.write("Daniel\n")
    f.write("Dorota\n")

with open('test.log', 'r', encoding='utf-8') as fh:
    lines = fh.read()
    print(lines)
    print(type(lines))

with open('test.log', 'r', encoding='utf-8') as fh:
   for x in fh:
       print(x)

