# funkcje zagniezdzone

def fun():
    print("To jest fun()")

    def fun2():
        print("To jest funkcja fun2()")

    return fun2

xfun1 = fun()
print(xfun1)
xfun1()
# fun()