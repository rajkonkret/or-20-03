wiek = 47  # int
rok = 2023  # int
temp = 36.6  # float - zmiennoprzecinkowy

print(wiek, rok, temp)

print(wiek + rok)
print(wiek - rok)
print(wiek * rok)
print(wiek / rok)  # w wyniku float
print(wiek // rok)  # częśc całkowita z dzielenia
print(wiek ** rok)  # potegowanie

print("Sprawdzam {} {}".format (wiek, temp))
print(f"\tSprawdzam {wiek} {temp}\n")
print(f"""
    {wiek}
    {temp}
    """)
imie = "Wiesiek Wiesiek"
print(imie)
print(imie.count(" "))

czy_znasz_pythona = False
czy_znasz_pythona = True

print(czy_znasz_pythona)
print(type(czy_znasz_pythona))
