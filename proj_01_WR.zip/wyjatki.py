def dzielenie(a, b):
    try:
        return a/ b
    except ZeroDivisionError:
        print("Nie dziel przez zero")

    except TypeError:
        print("Błędny argument")

    except Exception:
        print("Nieznany błąd")

    finally:
        print("Wykonany")

print(dzielenie(2, 1))