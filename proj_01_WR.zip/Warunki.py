# odp = input("czy znasz pythona(t/n)")
#
# if odp == 't':
#     print('Brawo')
# else:
#     print("Do nauki")

# podatek = 0.0
# zarobki = int(input("podaj dochód"))
# if zarobki < 10000:
#     podatek = 0.05
# elif zarobki < 30000:
#     podatek = 0.15
# else:
#     podatek = 0.6
#
# print(f"Zapłacisz {zarobki * podatek}")

# suma_zam = 167
# if suma_zam > 100:
#     rabacik = 25
# else:
#     rabacik = 0
#
# print("rabacik", rabacik)

# rabacik = 25 if suma_zam > 100 else 0
# print("rabacik 2", rabacik)

lista_bledow = []
alert_system = input('podaj system ')
error = 'critical'
error_message = 'Coś jest lipa'

if alert_system == 'console':
    print(error_message)
elif  alert_system == 'email':
    if error == 'medium':
        lista_bledow.append('medium')
    elif error == 'critical':
        lista_bledow.append('critical')
    else:
        lista_bledow.append('nieznany')
        print(lista_bledow)
else:
    print('nie ma takiego systemu')

