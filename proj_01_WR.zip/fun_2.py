a = 6
b = 8


# funkcja zwracajaca wynik
def dodaj():
    return a + b


print(dodaj() + dodaj())

wyn = dodaj()
print(wyn)


def mnozenie(a, b, c=1):
    return a * b * c


print(mnozenie(1, 2))

def oblicz_vat(cena, vat=23):
    return cena * (100 + vat) / 100


print(oblicz_vat(100))
