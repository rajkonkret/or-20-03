lista = []
jezyk = input("Podaj język")

match jezyk.lower():

    case "python":
        lista.append(jezyk.lower())
    case "java":
        lista.append(jezyk)
    case _:
        print("nie ma takiego systemu")


print(lista)
