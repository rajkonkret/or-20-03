# csv plik tekstowy w ktorym dane są rozdzielone znakiem
import csv

fields = ['name', 'branch', 'year', 'cgpa']
my_row_list =[
    {'branch': 'CEO', 'cgpa': '9.1', 'name': 'Jan', 'year': '22'},
    {'branch': 'CE1', 'cgpa': '4.1', 'name': 'Andrzej', 'year': '23'}
]

file = 'plik.csv'

with open(file, 'w', newline='') as csv_f:
    csvwriter = csv.DictWriter(csv_f, fieldnames=fields, delimiter='|')
    csvwriter.writeheader()
    csvwriter.writerows(my_row_list)

    print(fields)
    print(my_row_list)
    print(type(fields))
    print(type(my_row_list))



