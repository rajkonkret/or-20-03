import csv

filname = 'plik.csv'

fields = []
rows = []
with open(filname, 'r') as csv_f:
    csvreader = csv.reader(csv_f, delimiter='|')
    fields = next(csvreader)

    for row in csvreader:
        rows.append(row)
    print(csvreader)
    print(fields)
    print(rows[0])
    print(rows[1])
