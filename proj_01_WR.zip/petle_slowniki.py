slownik = {'name': 'Jan', 'nazwisko': 'Kowlaski'}
pusty_slownik = {}
print(type(slownik))
print(slownik)
print(type(pusty_slownik))
print(pusty_slownik)

# wypisanie kluczy
for k in slownik:
    print(k)
# wypisanie wartosci
for k in slownik.values():
    print(k)
# wypisanie kluczy 2
for k in slownik.keys():
    print(k)

# wypisanie itemow
for k, v in slownik.items():
    print(k, v)

# stworzyc dowolny slownik, wypisać fo wybnoru, klucze, wartosci, itemy

slownik_2 = {'kolor': 'zielony', 'wielkosc': 'duzy'}
for k in slownik_2:
    print(k)

for k in slownik_2.values():
    print(k)

for k in slownik_2.items():
    print(k)

slownik_3 = {'kolor': ['zielony', 'czerwony'], 'wielkosc': ['duzy', 'maly']}
# for k in slownik_3:
#     print(k)
#
# for k in slownik_3.values():
#     print(k)

for k, l in slownik_3.items():
    print(k, l)
    lista_22 =  print(k, l)
print(type(lista_22))

for k in slownik_3.items():
    print(k)
    lista_23 = print(k)
print(type(lista_23))

# petla z krokiem 2
for i in range(0, 10, 2):
    print(i)

# petla do tylu
for i in range(10 ,1, -1):
    print(i)