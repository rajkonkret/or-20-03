print()  # wypisz/wydrukuj na ekran/konsolę
print("Nazywam się Wiesiek")  # tekst - string
# ctrl+alt+l - wyrównanie kodu
print(39)  # int - liczby całkowite
print("39" + "15")  # łączenie tekstów
print(39 + 15)
print(5 * "4")

imie = "Wiesiek"  # str
print(type(imie))
print(imie)

wiek = 50  # int
print(type(wiek))
print(wiek)
# ctrl d - powielenie linijki

miasto = ("Warszawa")
print("Twoje miasto to: " + miasto)
print(type(miasto))
