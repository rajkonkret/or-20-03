# slownik - {"miasto":"Warszawa"}
# slownik = {"miasto": ["Warszawa", "Kraków"]}
# print(slownik)
# print(type(slownik))

slownik_2 = {'imie': 'name', 'kot': 'cat'}
slownik_2['nazwisko'] = 'surname'
print(slownik_2)
print(slownik_2['imie'])
print(slownik_2.keys())
print(slownik_2.values())
# key = input("podaj wyraz:")
# print(slownik_2[key])

# a = float(input("podaj liczbę a"))
# b = float(input("podaj liczbę b"))
#
# print(a + b)
