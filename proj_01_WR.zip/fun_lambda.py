# lambda - odpowiednik funkcji ale w formie krotkiego zapisu

def odejmij(a, b):
    return a - b


odejmij_2 = lambda a, b: a - b
oblicz_vat = lambda cena, vat=23: cena * (100 + vat) / 100

print(odejmij(4, 2))
print(odejmij_2(4, 2))
print(oblicz_vat(2))

wiek = lambda x: "dziecko" if x < 10 else ("nastolatek" if x < 18 else "dorosły")
print(wiek(20))

lista = [1, 2, 7, 8, 10, 55]
print(type(lista))
# zastosowanie funkcji map - mapowanie jednych danych na inne
# f  {} - formatowanie tekstu, w klamrach mozna umieścić wynik działania, lub zmienna
print(f"Zastosowanie map: {list(map(lambda x: x * 2, lista))}")
lista_po_uzyciu_lambdy = (print(f"Zastosowanie map: {list(map(lambda x: x * 2, lista))}"))
print(type(lista_po_uzyciu_lambdy))

# filter() - filtruje  dane
print(f"Zastosowanie filter() {list(filter(lambda x: x < 3, lista))}")
print(f"Zastosowanie filter() {list(filter(lambda x: x > 8, lista))}")
print(f"Zastosowanie filter() {list(filter(lambda x: 3 < x < 20, lista))}")


