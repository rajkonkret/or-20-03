a = 10  # zmienna globalna


def dodaj():
    a = 4 # zmienne lokalne
    b = 10
    print("Wynik", a + b)


def dodaj_2():
    global a
    a = 4 # zmienne lokalne
    b = 10
    print("Wynik", a + b)


print("Wartość a z góry (globalnej)", a)
dodaj()
print("Wartość a z góry (globalnej)", a)
dodaj_2()
print("Wartość a z góry (globalnej)", a)
