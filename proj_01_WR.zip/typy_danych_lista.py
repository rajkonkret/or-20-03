lista_01 = []  # deklaracja listy
print(lista_01)
print(type(lista_01))
lista_01.append("Warszawa")
lista_01.append("Kraków")
lista_01.append("Poznań")
lista_01.append("Gdańsk")
print(lista_01)
print(lista_01[0])
lista_01.insert(1, "Olsztyn")
print(lista_01)
lista_01[3] = "Szczecin"
print(lista_01)
liczby_01 = []
print(liczby_01)
print(len(liczby_01))

