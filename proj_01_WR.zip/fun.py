a = 1
b = 2
def test(a, b):
    print(a + b)

test(1, 2)

def test_2(a, b, c=1):
    print(a + b -c)

test_2(1, 2)