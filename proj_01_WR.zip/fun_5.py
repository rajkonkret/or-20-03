# definicja funkcji
# funkcja kantor zwracajaca funkcje do przeliczania konkretnej waluty
def kantor(waluta):
    print("Uruchomienie kantoru")

    def usd(kwota):
        print("Przelicz dolary")
        print(4.1 * kwota)

    def eur(kwota):
        print("Przelicz euro")
        print(4.5 * kwota)

    if waluta.upper() == "USD":
        return usd
    else:
        return eur


podaj_walute = input("Podaj walute")
moj_kantor = kantor(podaj_walute)
# ilosc_do_wymiany = int(input("Ile chcesz wymienić?:"))
moj_kantor(100)