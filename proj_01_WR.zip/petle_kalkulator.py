# uzycie petli while True jako głónej petli programu
while True:
    print("""
    1. Dodawnia
    2. Odejmowanie
    3. Mnożenie
    5. Koniec
    """)
    wybor = input("Podaj działanie")
    if wybor == '5':
        break
    if wybor not in ['1', '2', '3']:
        print("Zła opcja")
    a = int(input("Podaj liczbę a"))
    b = int(input("Podaj liczbę b"))
    if wybor == '1':
        print(a + b)
    elif wybor == '2':
        print(a -b)
    elif wybor == '3':
        print(a * b)

